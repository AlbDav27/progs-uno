#include <mosquittopp.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>             /* File Control Definitions           */

#include <termios.h>      /* POSIX Terminal Control Definitions */

#include <unistd.h>         /* UNIX Standard Definitions            */

#include <errno.h>           /* ERROR Number Definitions           */

#include <sys/ioctl.h>   /* ioctl() */

#include <unistd.h> 	//para funcion sleep()  ...delay
#include <string.h>

int main(){
	int num =598732;
	int c =num/100;
	int nt = num-(c*100);
	int d = nt/10;
	int u = nt-(d*10);
	printf("\nEl número original es : %d", num);
	printf("\nCentenas : %d", c);
	printf("\nDEcenas : %d",d);
	printf("\nUNidades : %d \n",u);
	char cad[10];
	sprintf(cad,"%d", num);
	printf("Esto es una cadena: %s\n", cad);
}
